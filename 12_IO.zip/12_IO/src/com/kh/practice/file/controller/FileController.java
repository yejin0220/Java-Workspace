package com.kh.practice.file.controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.kh.practice.file.model.dao.FileDao;

public class FileController {
	
	FileDao fd = new FileDao();
	
	public boolean checkName(String file) {
		return fd.checkName(file);

		
	}
	
	
	public void fileSave(String file, StringBuilder sb) {
		
		
	}
	
	public StringBuilder fileOpen(String file) {
		return fd.fileOpen(file);
		
	}
	
	
	public void fileEdit(String file, StringBuilder) {
		
		
		
	}

}
