package com.kh.chap02_abstractAndInterface.part02_family.run;

public class Run {

	public static void main(String[] args) {
	

	}

}
